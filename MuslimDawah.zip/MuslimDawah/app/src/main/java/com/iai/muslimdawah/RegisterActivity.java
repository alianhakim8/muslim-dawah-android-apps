package com.iai.muslimdawah;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

import static maes.tech.intentanim.CustomIntent.customType;

public class RegisterActivity extends AppCompatActivity {

    // declaration
    private EditText username, userPassword, userEmail, userConfirmPassword;
    private TextView loginTextView;
    private String userName, Password, Email, ConfirmPassword;
    public static final String PREFERENCE = "preference";
    public static final String PREF_EMAIL = "email";
    public static final String PREF_NAME = "name";
    public static final String PREF_PASSWORD = "password";
    public static final String PREF_CONFIRM_PASSWORD = "confirm_password";

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Objects.requireNonNull(getSupportActionBar()).hide();
        setContentView(R.layout.activity_register);
        username = findViewById(R.id.username_register);
        userPassword = findViewById(R.id.password_register);
        Button registerButton = findViewById(R.id.register_button);
        loginTextView = findViewById(R.id.login_textView);

        // register button onClick method
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validUserData()) {
                    SharedPreferences SharedPreference = getSharedPreferences(PREFERENCE, Context.MODE_PRIVATE);
                    SharedPreferences.Editor Editor = SharedPreference.edit();
                    //Editor.putString(PREF_EMAIL, Email);
                    Editor.putString(PREF_NAME, userName);
                    Editor.putString(PREF_PASSWORD, Password);
                    //Editor.putString(PREF_CONFIRM_PASSWORD, ConfirmPassword);
                    Editor.apply();

                    Toast.makeText(RegisterActivity.this, "Register Successfully", Toast.LENGTH_SHORT).show();
                    Intent loginActivity = new Intent(getApplicationContext(), LoginActivity.class);
                    loginActivity.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(loginActivity);
                    finish();
                } else {
                    Toast.makeText(RegisterActivity.this, "Registered Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        loginTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginScreen = new Intent(getApplicationContext(), LoginActivity.class);
                loginScreen.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(loginScreen);
                customType(RegisterActivity.this, "up-to-bottom");

            }
        });
    }

    // check user method
    private boolean validUserData() {
        userName = username.getText().toString().trim();
        Password = userPassword.getText().toString().trim();
        //Email = userEmail.getText().toString().trim();

        //ConfirmPassword = userConfirmPassword.getText().toString().trim();
        return !(userName.isEmpty() || Password.isEmpty());
    }
}
