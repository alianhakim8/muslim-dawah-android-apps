package com.iai.muslimdawah;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Objects;

import static maes.tech.intentanim.CustomIntent.customType;

public class LoginActivity extends AppCompatActivity {

    private TextInputLayout usernameInput;
    private TextInputEditText username;
    private EditText userPassword;
    private SharedPreferences SharedPreferences;
    public static final String PREFERENCE = "preference";
    public static final String PREF_NAME = "name";
    public static final String PREF_PASSWORD = "password";
    public static final String PREF_SKIP_LOGIN = "skip_login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Objects.requireNonNull(getSupportActionBar()).hide();
        setContentView(R.layout.activity_login);


//        SharedPreferences = getSharedPreferences(PREFERENCE, Context.MODE_PRIVATE);
//        if (SharedPreferences.contains(PREF_SKIP_LOGIN)) {
//            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
//            startActivity(intent);
//            finish();
//            Intent intent1 = new Intent(getApplicationContext(), MainActivity.class);
//            startActivity(intent1);
//        } else {
//            username = findViewById(R.id.username_login);
//            userPassword = findViewById(R.id.password_login);
//            Button mLogin = findViewById(R.id.button_login);
            TextView mRegister = findViewById(R.id.register_textView);
//            mLogin.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    if (validUserData()) {
//                        if (SharedPreferences.contains(PREF_NAME) && SharedPreferences.contains(PREF_PASSWORD)) {
//                            SharedPreferences.Editor mEditor = SharedPreferences.edit();
//                            mEditor.putString(PREF_SKIP_LOGIN, "skip");
//                            mEditor.apply();
//                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
//                            startActivity(intent);
//                            finish();
//                        } else {
//                            Toast.makeText(getApplicationContext(), "Invalid login username or password", Toast.LENGTH_SHORT).show();
//                        }
//                    } else {
//                        Toast.makeText(getApplicationContext(), "Please fill out field", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
            mRegister.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    customType(LoginActivity.this, "bottom-to-up");

                }
            });
        }
    }

//    private boolean validUserData() {
//        String name = username.getText().toString().trim();
//        String password = userPassword.getText().toString().trim();
//        return !(name.isEmpty() || password.isEmpty());
//    }
//}
